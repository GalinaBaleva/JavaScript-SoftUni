function solve(){
               alert(`You need registration to have the opportunity to buy from our shop!`);
               return;
};
solve();